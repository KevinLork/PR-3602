#define TAILLEBUF 8191

#define R 0
#define W 1

char * litLigne(int fd);
int ecritLigne(int fd, char *c);
