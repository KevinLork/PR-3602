#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "lectureEcriture.h"

int main(int argc, char **argv) {
// clavier-fichier vers terminal
	// int clavier = 0;
	// int shell = 1;
	int clavier;
	int shell;
	if (argc >= 2) {

		clavier = atoi(argv[0]);	//entree
		shell = atoi(argv[1]);		//sortie
		//https://stackoverflow.com/questions/2797813/how-to-convert-a-command-line-argument-to-int
	}
	else{
		perror("parametre d'entree et sortie a preciser");
		exit(0);
	}

	int recu = 0;
	char* entree = litLigne(clavier);

	if (entree == NULL) {
		perror("TestLectureEcriture - litLigne");
		exit(0);
	} 
		else {
			// printf("Ca ne devrait pas arriver\n");
			ecritLigne(shell, entree);
			recu = 1;
		}
	
	if (recu == 1){
		char* printrep = "message recu, ecrire une reponse\n";
		ecritLigne(shell, printrep);
		
		char* reponse = litLigne(clavier);
		ecritLigne(shell, reponse);
	}
	
return 0;
}

// terminal vers shell-vers aquisition
// aquisition vers terminal
// terminal vers ecran
