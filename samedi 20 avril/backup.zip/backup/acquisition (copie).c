#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "lectureEcriture.h"
#include "message.h"
#include <semaphore.h>

int nb_term = 3;
	int fd2[2];
	int fd3[2];
sem_t semaphore;
sem_t semaphore2;

	
typedef struct args_threads_term {
	// char* name;
	// int age;
	int fd_entree_auto;
	int fd_entree_term;
	int fd_sortie_term;
	char** tab_cb_struct;
	int* tab_pipe;
}args_threads_term;
typedef struct args_threads_glob {

	int fd_sortie_auto;
	char** tab_cb_struct;
	int* tab_pipe;
}args_threads_glob;

void *threading_term(void *input) {
									// char* mes_lu_auto;
	char* mes_lu_term;
	
	printf("threading_term: je suis un thread\n");


	//lit pipe sortant du terminal
	while(1) {

		// tab[i][0] = fd0[0];	//pipe term o<---
		// tab[i][1] = fd0[1];	//pipe term <---o
		// tab[i][2] = fd1[0];	//pipe term --->o
		// tab[i][3] = fd1[1];	//pipe term o--->
		printf("rentre dans le while de threading_term\n");
		
		// printf("%d\n", ((struct args_threads_term*)input)->fd_sortie_term);
		// sem_wait(&semaphore2);
		mes_lu_term = litLigne(((struct args_threads_term*)input)->fd_sortie_term);
		// sem_post(&semaphore2);
		printf("%s\n", mes_lu_term);
		// printf("acq: a lu mes_term\n");
		// printf("acq: %s\n", mes_lu_term);
		printf("transmet la demande\n");

		//ecrit dans le pipe vers autorisation
		// sem_wait(&semaphore);
		ecritLigne(((struct args_threads_term*)input)->fd_entree_auto, mes_lu_term);
		// sem_post(&semaphore);
		// printf("%d\n", ((struct args_threads_term*)input)->fd_entree_auto);
		
									// //lit pipe sortant de autorisation
									// // sem_wait(&semaphore2);
									// mes_lu_auto = litLigne(fd3[0]);
									// // sem_post(&semaphore2);
									// // printf("acq: a lu mes_auto\n");
									// // printf("acq: %s\n", mes_lu_auto);
									// printf("transmet l'autorisation\n");
									// //ecrit dans le pipe vers terminal
									// ecritLigne(((struct args_threads_term*)input)->fd_entree_term, mes_lu_auto);
									// // printf("%d\n", ((struct args_threads_term*)input)->fd_entree_term);
	}
	return 0;
}

void *threading_glob(void *input) {
	char* mes_lu_auto;
	
	printf("threading_glob: je suis un thread\n");


	//lit pipe sortant du terminal
	while(1) {

		// tab[i][0] = fd0[0];	//pipe term o<---
		// tab[i][1] = fd0[1];	//pipe term <---o
		// tab[i][2] = fd1[0];	//pipe term --->o
		// tab[i][3] = fd1[1];	//pipe term o--->
		printf("rentre dans le while de threading_glob\n");
		// printf("%d\n", ((struct args_threads_glob*)input)->fd_sortie_auto);
		mes_lu_auto = litLigne(((struct args_threads_glob*)input)->fd_sortie_auto);
		printf("%s\n", mes_lu_auto);
		char cb[255], type[255], valeur[255];

		int fd_term_tab_pipe;

		decoupe(mes_lu_auto, cb, type, valeur);
		for (int i =0; i < nb_term; i++){
			if (cb ==((struct args_threads_glob*)input)->tab_cb_struct[i]) {
				fd_term_tab_pipe = ((struct args_threads_glob*)input)->tab_pipe[i];
			}
		}

		// printf("acq: a lu mes_term\n");
		// printf("acq: %s\n", mes_lu_term);
		printf("transmet la demande\n");

		//ecrit dans le pipe vers autorisation
		ecritLigne(fd_term_tab_pipe, mes_lu_auto);
		printf("%d\n", fd_term_tab_pipe);
		
		// sem_post(&semaphore2);
		// //lit pipe sortant de autorisation
		// mes_lu_auto = litLigne(fd3[0]);
		// // printf("acq: a lu mes_auto\n");
		// // printf("acq: %s\n", mes_lu_auto);
		// printf("transmet l'autorisation\n");
		// //ecrit dans le pipe vers terminal
		// ecritLigne(((struct args_threads_term*)input)->fd_entree_term, mes_lu_auto);
		// printf("%d\n", ((struct args_threads_term*)input)->fd_entree_term);
	}
	return 0;

}

void* fonction_thread_term (int arg1, int arg2, int arg3, char** arg4, int* arg5){
	struct args_threads_term *struct_thread = (struct args_threads_term *)malloc(sizeof(struct args_threads_term));
	// char allen[] = "Allen";
	// Allen->name = allen;
	// Allen->age = 20;
	printf("fonction_thread_term rempli les pipes avec ses params\n");
	struct_thread->fd_entree_auto = arg1;//auto <---o
	struct_thread->fd_entree_term = arg2;//term <---o
	struct_thread->fd_sortie_term = arg3;//term --->o
	struct_thread->tab_cb_struct = arg4;
	struct_thread->tab_pipe = arg5;



	pthread_t tid;
	// printf("fonction thread va creer un thread\n");
	printf("fonction_thread_term va créer un thread\n");
	pthread_create(&tid, NULL, threading_term, (void *)struct_thread);
	printf("en a cree un \n");
	// pthread_join(tid, NULL);
	return 0;
}

void* fonction_thread_glob (int arg1, char** arg4, int* arg5){
	struct args_threads_glob *struct_thread = (struct args_threads_glob *)malloc(sizeof(struct args_threads_glob));
	// char allen[] = "Allen";
	// Allen->name = allen;
	// Allen->age = 20;
	printf("fonction_thread_glob rempli les pipes avec ses params\n");
	struct_thread->fd_sortie_auto = arg1;//auto <---o
	struct_thread->tab_cb_struct = arg4;
	struct_thread->tab_pipe = arg5;



	pthread_t tid;
	// printf("fonction thread va creer un thread\n");
	printf("fonction_thread_glob va créer un thread\n");
	pthread_create(&tid, NULL, threading_glob, (void *)struct_thread);
	printf("en a cree un \n");
	// pthread_join(tid, NULL);
	return 0;
}	



int main(int argc, char **argv) {
	
	char **tab_cb = malloc(sizeof(char[255])*nb_term);
	int *tab_pipe = malloc(sizeof(int)*nb_term);




// ===============<CREATION DE PIPES>=======================

	if (pipe(fd2) == -1) {
		perror("pipe");
		exit(EXIT_FAILURE);
	}
	if (pipe(fd3) == -1) {
		perror("pipe");
		exit(EXIT_FAILURE);
	}
	// creation de pipe temporaire pour stackage dans tableau de pipe
	int fd0[2];
	int fd1[2];
	// creation du tableau de stockage de pipe
	int tab[nb_term][4];

	for (int i =0; i < nb_term; i++) {

		// initialisation
		if (pipe(fd0) == -1) {
			perror("pipe");
			exit(EXIT_FAILURE);
		}
		if (pipe(fd1) == -1) {
			perror("pipe");
			exit(EXIT_FAILURE);
		}

		// mise en tableau
		tab[i][0] = fd0[0];
		tab[i][1] = fd0[1];
		tab[i][2] = fd1[0];
		tab[i][3] = fd1[1];
	}
	printf("la creation des pipes est terminée\n");



	pid_t pid;
	pid_t pid2;

// Creation des processus, tubes et recouvrement

	printf("acq: je vais creer un fils terminal\n");
//le fils - terminal
	for (int i = 0; i < nb_term; i++) {	
		pid = fork();
		
		if (pid == 0){
			printf("- je suis le fils terminal%d\n",i);
			printf("\n");

			// tab[i][0] = fd0[0];	//pipe term o<---
			// tab[i][1] = fd0[1];	//pipe term <---o
			// tab[i][2] = fd1[0];	//pipe term --->o
			// tab[i][3] = fd1[1];	//pipe term o--->

			close(tab[i][1]);
			close(tab[i][2]);

			char s_fd0[50], s_fd1[50];

			sprintf(s_fd0, "%d", tab[i][0]);
			sprintf(s_fd1, "%d", tab[i][3]);

			execl("/usr/bin/xterm","/usr/bin/xterm","-hold","-e","./terminal", s_fd0, s_fd1, NULL);
			// printf("j'ai exec terminal.c\n");
		}
		else if(pid < 0){	//erreur
			perror("erreur fork1");
			exit(EXIT_FAILURE);
		}
	}
// 
	
	printf("acq: je vais creer un fils autorisation\n");
//fils - autorisation
	pid2 = fork();

	if(pid2 == 0){
		printf("- je suis le fils autorisation\n");
		printf("\n");

		close(fd2[1]);
		close(fd3[0]);
		
		char s_fd2[50], s_fd3[50];

		sprintf(s_fd2, "%d", fd2[0]);
		sprintf(s_fd3, "%d", fd3[1]);

		execl("/usr/bin/xterm","/usr/bin/xterm","-hold","-e","./autorisation", s_fd2, s_fd3, NULL);
		// printf("j'ai exec autorisation.c\n");
	}
	else if (pid2 < 0){
		perror("erreur fork2");
		exit(EXIT_FAILURE);
	}

// 

// ===============<CREATION DE THREADS>=====================
	for (int i = 0; i < nb_term; i++) {
		
		printf("============================================\n");
		printf("rentre dans la boucle de creation de threads\n");

		printf("etape:%d; %d,%d,%d\n",i, fd2[1], tab[i][1], tab[i][2]);
		fonction_thread_term (fd2[1], tab[i][1], tab[i][2], tab_cb, tab_pipe);



		// tab[i][0] = fd0[0];	//pipe term o<---
		// tab[i][1] = fd0[1];	//pipe term <---o
		// tab[i][2] = fd1[0];	//pipe term --->o
		// tab[i][3] = fd1[1];	//pipe term o--->
		// printf("réussit a créer un thread\n");
	}
	printf("============================================\n");
	printf("crée le thread global\n");
	fonction_thread_glob (fd3[0], tab_cb, tab_pipe);

	printf("====================================\n");
	printf("la creation des threads est terminée\n");
	printf("====================================\n");





// #############################################################

// Lecture ecriture des messages

//pere



	// char* mes_lu_auto;
	// char* mes_lu_term;


	// close(fd0[0]);
	// close(fd1[1]);
	// close(fd2[0]);
	// close(fd3[1]);

	// //lit pipe sortant du terminal
	// while(1) {
	// 	for (int i = 0; i < nb_term; i++) {	

	// 		// tab[i][0] = fd0[0];	//pipe term o<---
	// 		// tab[i][1] = fd0[1];	//pipe term <---o
	// 		// tab[i][2] = fd1[0];	//pipe term --->o
	// 		// tab[i][3] = fd1[1];	//pipe term o--->

	// 		mes_lu_term = litLigne(tab[i][2]);
	// 		// printf("acq: a lu mes_term\n");
	// 		// printf("acq: %s\n", mes_lu_term);
	// 		printf("transmet la demande\n");

	// 		//ecrit dans le pipe vers autorisation
	// 		ecritLigne(fd2[1], mes_lu_term);
			
	// 		//lit pipe sortant de autorisation
	// 		mes_lu_auto = litLigne(fd3[0]);
	// 		// printf("acq: a lu mes_auto\n");
	// 		// printf("acq: %s\n", mes_lu_auto);
	// 		printf("transmet l'autorisation\n");
	// 		//ecrit dans le pipe vers terminal
	// 		ecritLigne(tab[i][1], mes_lu_auto);
	// 	}

	// }

	return 0;
}